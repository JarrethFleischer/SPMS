<?php
session_start();
if (!isset($_SESSION['email'])) {

    header("Location: ../login.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <title>Student Add</title>
    <link href="https://cdn.jsdelivr.net/npm/simple-datatables@7.1.2/dist/style.min.css" rel="stylesheet" />
    <link href="../css/styles.css" rel="stylesheet" />
    <script src="https://use.fontawesome.com/releases/v6.3.0/js/all.js" crossorigin="anonymous"></script>
    <style>
    .form-group {
        margin-bottom: 1rem;
    }

    .card-body {
        padding: 2rem;
    }
    </style>
</head>

<body class="sb-nav-fixed">
    <?php include "../topbar.php"?>
    <div id="layoutSidenav">
        <?php include "../sidebar.php"?>
        <div id="layoutSidenav_content">
            <main>
                <div class="container-fluid px-4">
                    <h1 class="mt-4">Add New Student</h1>
                    <ol class="breadcrumb mb-4">
                        <li class="breadcrumb-item active">Student Information</li>
                    </ol>

                    <div class="card mb-4">
                        <div class="card-header">
                            <h5 class="card-title">Student Information</h5>
                        </div>
                        <div class="card-body">
                            <form>
                                <div class="form-group">
                                    <label for="studentName">Name</label>
                                    <input type="text" class="form-control" id="studentName"
                                        placeholder="Enter student's name" required>
                                </div>
                                <div class="form-group">
                                    <label for="birthDate">Birth Date</label>
                                    <input type="date" class="form-control" id="birthDate" required>
                                </div>
                                <div class="form-group">
                                    <label for="birthCertNo">Birth Certification No.</label>
                                    <input type="text" class="form-control" id="birthCertNo"
                                        placeholder="Enter birth certification number" required>
                                </div>
                                <div class="form-group">
                                    <label for="address">Address</label>
                                    <input type="text" class="form-control" id="address" placeholder="Enter address"
                                        required>
                                </div>
                                <div class="form-group">
                                    <label for="class">Class</label>
                                    <select class="form-control" id="class" required>
                                        <option value="" disabled selected>Select class</option>
                                        <option value="class1">Class 1</option>
                                        <option value="class2">Class 2</option>
                                        <option value="class3">Class 3</option>
                                    </select>
                                </div>
                                <br>
                                <hr>
                                <br>
                                <h5>Guardian Information</h5>
                                <div class="form-group">
                                    <label for="guardianName">Guardian Name</label>
                                    <input type="text" class="form-control" id="guardianName"
                                        placeholder="Enter guardian's name" required>
                                </div>
                                <div class="form-group">
                                    <label for="guardianAddress">Guardian Address</label>
                                    <input type="text" class="form-control" id="guardianAddress"
                                        placeholder="Enter guardian's address" required>
                                </div>
                                <div class="form-group">
                                    <label for="guardianPhone">Guardian Phone No.</label>
                                    <input type="tel" class="form-control" id="guardianPhone"
                                        placeholder="Enter guardian's phone number" required>
                                </div>
                                <div class="form-group">
                                    <label for="guardianOccupation">Guardian Occupation</label>
                                    <input type="text" class="form-control" id="guardianOccupation"
                                        placeholder="Enter guardian's occupation" required>
                                </div>
                                <button type="submit" class="btn btn-primary">Submit</button>
                                <button type="reset" class="btn btn-danger">Reset</button>
                            </form>
                        </div>
                    </div>
                </div>
            </main>
            <footer class="py-4 bg-light mt-auto">
                <div class="container-fluid px-4">
                    <div class="d-flex align-items-center justify-content-between small">
                        <div class="text-muted">Copyright &copy; Sekolah Pondok Miftahussalam</div>
                    </div>
                </div>
            </footer>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous">
    </script>
    <script src="js/scripts.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.8.0/Chart.min.js" crossorigin="anonymous"></script>
    <script src="../assets/demo/chart-area-demo.js"></script>
    <script src="../assets/demo/chart-bar-demo.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/simple-datatables@7.1.2/dist/umd/simple-datatables.min.js"
        crossorigin="anonymous"></script>
    <script src="../js/datatables-simple-demo.js"></script>
</body>

</html>