<?php
session_start();
include("../db/conn.php");

if (isset($_POST['email'])) {
    $email = $_POST['email'];
    $password = trim($_POST['password']);

    $query = "SELECT * FROM user WHERE email = '$email'";
    $result = mysqli_query($conn, $query);

    if ($result) {
        if (mysqli_num_rows($result) === 1) {
            $row = mysqli_fetch_assoc($result);
            $stored_password = $row['password'];
            $user_level = $row['user_level']; // Get user_level

            if ($password === $stored_password) {
                $_SESSION['email'] = $row['email'];
                $_SESSION['first_name'] = $row['first_name'];
                $_SESSION['user_level'] = $user_level; // Store user_level in session

                // Send user_level back to the client
                echo $user_level;
            } else {
                // Incorrect password
                echo "Incorrect password";
            }
        } else {
            // User not found
            echo "User not found";
        }
    } else {
        // Query failed
        echo "Query failed: " . mysqli_error($conn);
    }
}
?>