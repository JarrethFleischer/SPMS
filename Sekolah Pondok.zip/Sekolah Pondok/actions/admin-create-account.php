<?php
session_start();
if (!isset($_SESSION['email'])) {
    header("Location: login.php");
    exit();
}

include("../db/conn.php");

// Retrieve and sanitize form data
$firstName = $conn->real_escape_string($_POST['firstName']);
$lastName = $conn->real_escape_string($_POST['lastName']);
$phone = $conn->real_escape_string($_POST['phone']);
$birthdate = $conn->real_escape_string($_POST['birthdate']);
$class = $conn->real_escape_string($_POST['class']);
$email = $conn->real_escape_string($_POST['email']);
$password = $conn->real_escape_string($_POST['password']);
$confirmPassword = $conn->real_escape_string($_POST['confirmPassword']);
$userLevel = 2; // Default user level

// Validate passwords match
if ($password !== $confirmPassword) {
    echo "<div style='background-color: red; color: white; padding: 10px; border-radius: 5px;'>
            Passwords do not match.
          </div>";
    exit();
}

// Prepare and execute the SQL statement
$sql = "INSERT INTO user (first_name, last_name, phone_no, birthdate, class, email, password, user_level)
        VALUES ('$firstName', '$lastName', '$phone', '$birthdate', '$class', '$email', '$password', $userLevel)";

if ($conn->query($sql) === TRUE) {
    echo "<div style='background-color: green; color: white; padding: 10px; border-radius: 5px;'>
            New teacher account created successfully.
          </div>";
} else {
    echo "<div style='background-color: red; color: white; padding: 10px; border-radius: 5px;'>
            Error: " . $conn->error . "
          </div>";
}

$conn->close();
?>