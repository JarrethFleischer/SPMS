<div id="layoutSidenav_nav">
    <nav class="sb-sidenav accordion sb-sidenav-dark" id="sidenavAccordion">
        <div class="sb-sidenav-menu">
            <div class="nav">
                <div class="sb-sidenav-menu-heading">Core</div>
                <!--Dashboard-->
                <a class="nav-link" href="../admin.php">
                    <div class="sb-nav-link-icon">
                        <i class="fas fa-tachometer-alt"></i>
                    </div>
                    Dashboard
                </a>

                <a class="nav-link" href="../admin/create-account.php">
                    <div class="sb-nav-link-icon">
                        <i class="fas fa-tachometer-alt"></i>
                    </div>
                    Create Teacher Account
                </a>

                <!--Students part-->
                <a class="nav-link collapsed" href="#" data-bs-toggle="collapse" data-bs-target="#collapseStudents"
                    aria-expanded="false" aria-controls="collapseStudents">
                    <div class="sb-nav-link-icon">
                        <i class="fas fa-user-graduate"></i>
                    </div>
                    Teachers
                    <div class="sb-sidenav-collapse-arrow">
                        <i class="fas fa-angle-down"></i>
                    </div>
                </a>
                <div class="collapse" id="collapseStudents" aria-labelledby="headingStudents"
                    data-bs-parent="#sidenavAccordion">
                    <nav class="sb-sidenav-menu-nested nav">
                        <a class="nav-link" href="../admin/edit-account.php">Teacher Edit</a>
                        <a class="nav-link" href="../admin/class-report.php">Class Report</a>
                    </nav>
                </div>
                <!--End Students part-->
            </div>
        </div>
        <div class="sb-sidenav-footer">
            <div class="small">Logged in as:</div>
            <?php 
                        if(isset($_SESSION['first_name'])) {
                            echo htmlspecialchars($_SESSION['first_name']);
                        } else {
                            echo 'Guest';
                        }
                    ?>
        </div>
    </nav>
</div>