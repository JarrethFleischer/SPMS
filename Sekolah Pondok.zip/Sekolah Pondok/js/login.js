$(document).ready(function () {
  $("#loginButton").on("click", function () {
    var email = $("#inputEmail").val();
    var password = $("#inputPassword").val();

    $.ajax({
      type: "POST",
      url: "../actions/login_actions.php",
      data: {
        email: email,
        password: password,
      },
      success: function (response) {
        if (response === "1") {
          window.location.href = "../admin.php";
        } else if (response === "2") {
          window.location.href = "../index.php";
        } else {
          $("#errorMessages").text(response);
          $("#inputEmail").val("");
          $("#inputPassword").val("");
        }
      },
      error: function () {
        $("#errorMessages").text(
          "An error occurred while processing your request."
        );
      },
    });
  });
});
