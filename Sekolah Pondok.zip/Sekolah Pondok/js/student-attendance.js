$(document).ready(function () {
  $("#studentTable").DataTable();
});

function showStudents(classId) {
  const students = {
    class1: [
      {
        id: 1,
        name: "John Doe",
      },
      {
        id: 2,
        name: "Jane Smith",
      },
    ],
    class2: [
      {
        id: 3,
        name: "Alice Johnson",
      },
      {
        id: 4,
        name: "Bob Brown",
      },
    ],
  };

  const studentTable = $("#studentTable").DataTable();
  studentTable.clear();

  if (students[classId]) {
    students[classId].forEach((student) => {
      studentTable.row
        .add([
          student.name,
          `<select>
                            <option value="attend">Attend</option>
                            <option value="absent">Absent</option>
                            <option value="sick">Sick Leave</option>
                        </select>`,
        ])
        .draw();
    });
  }
}
