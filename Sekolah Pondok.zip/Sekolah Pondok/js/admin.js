document.addEventListener("DOMContentLoaded", function () {
  const form = document.getElementById("createTeacherForm");
  form.addEventListener("submit", function (event) {
    event.preventDefault();

    const formData = new FormData(form);
    const xhr = new XMLHttpRequest();
    xhr.open("POST", "../actions/admin-create-account.php", true);
    xhr.setRequestHeader("X-Requested-With", "XMLHttpRequest");

    xhr.onload = function () {
      if (xhr.status >= 200 && xhr.status < 300) {
        const responseDiv = document.getElementById("responseMessage");
        responseDiv.innerHTML = xhr.responseText;

        // Check if the response contains success message
        if (
          xhr.responseText.includes("New teacher account created successfully")
        ) {
          form.reset(); // Clear form inputs
        }
      } else {
        document.getElementById("responseMessage").innerHTML =
          "An error occurred: " + xhr.statusText;
      }
    };

    xhr.onerror = function () {
      document.getElementById("responseMessage").innerHTML = "Request failed";
    };

    xhr.send(formData);
  });
});
